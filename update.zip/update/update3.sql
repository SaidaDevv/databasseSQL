update customer

set create_date = now()

where customer_id = 5;