UPDATE film set rental_duration = 21,rental_rate = 9.99 where film_id = 1001;
